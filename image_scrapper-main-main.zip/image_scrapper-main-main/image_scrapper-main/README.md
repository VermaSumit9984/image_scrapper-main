# Image Scrapper

### Requirements
- python>=3.8
- Chromedriver in the root directory
